export class Todo{
    sno: number
    title: string
    desc: string
    active: boolean
}